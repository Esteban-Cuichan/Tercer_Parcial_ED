/*
---------------------------------------------------------
PROBLEMA: RECOLECCION MAXIMA DE MONEDAS
---------------------------------------------------------

Enunciado:

Se tiene una matriz cuadrada de tamaño N x N que
contiene cantidades de monedas generadas aleatoriamente.

Un jugador inicia en la esquina superior izquierda
(0,0) y desea llegar a la esquina inferior derecha
(N-1,N-1).

Movimientos permitidos:
    - Derecha
    - Abajo

Objetivo:
Determinar la maxima cantidad de monedas que puede
recoger durante el recorrido utilizando
Programacion Dinamica.

Adicionalmente se debe mostrar el camino optimo seguido
y los valores de monedas recogidos en cada posicion.

Complejidad:
    Tiempo: O(N²)
    Espacio: O(N²)

---------------------------------------------------------
*/

#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;


// Devuelve el mayor de dos números
int maximo(int a, int b) {
    return (a > b) ? a : b;
}


int main() {


    // Inicializa la semilla para generar
    // números aleatorios diferentes en cada ejecución
    srand((unsigned)time(NULL));


    int n;


    // Validación del tamaño de la matriz
    do {

        cout << "Ingrese el tamaño de la matriz cuadrada: ";
        cin >> n;


        if (n <= 0) {
            cout << "ERROR: El tamaño debe ser mayor que cero.\n\n";
        }


    } while (n <= 0);



    // Reserva memoria para la matriz original
    // y para la tabla de Programación Dinámica

    int** matriz = new int*[n];
    int** dp = new int*[n];


    for (int i = 0; i < n; i++) {

        *(matriz + i) = new int[n];
        *(dp + i) = new int[n];

    }



    // Generación de monedas aleatorias

    cout << "\n===== MATRIZ DE MONEDAS =====\n\n";


    for (int i = 0; i < n; i++) {


        for (int j = 0; j < n; j++) {


            *(*(matriz + i) + j) = rand() % 9 + 1;


            cout << *(*(matriz + i) + j) << "\t";

        }


        cout << endl;

    }



    /*
    ------------------------------------------------
    CONSTRUCCION DE LA TABLA DP

    Cada posición almacena la máxima cantidad
    de monedas acumuladas hasta llegar a ella.
    ------------------------------------------------
    */


    // Caso base

    *(*(dp + 0) + 0) =
        *(*(matriz + 0) + 0);



    // Primera fila
    // Solo puede venir desde la izquierda

    for (int j = 1; j < n; j++) {


        *(*(dp + 0) + j) =
            *(*(dp + 0) + (j - 1))
            +
            *(*(matriz + 0) + j);

    }



    // Primera columna
    // Solo puede venir desde arriba

    for (int i = 1; i < n; i++) {


        *(*(dp + i) + 0) =
            *(*(dp + (i - 1)) + 0)
            +
            *(*(matriz + i) + 0);

    }




    // Programación Dinámica

    for (int i = 1; i < n; i++) {


        for (int j = 1; j < n; j++) {



            *(*(dp + i) + j) =

                *(*(matriz + i) + j)

                +

                maximo(

                    *(*(dp + (i - 1)) + j),

                    *(*(dp + i) + (j - 1))

                );


        }

    }




    // Mostrar tabla DP

    cout << "\n===== TABLA DP =====\n\n";


    for (int i = 0; i < n; i++) {


        for (int j = 0; j < n; j++) {


            cout << *(*(dp + i) + j)
                 << "\t";

        }


        cout << endl;

    }





    /*
    ------------------------------------------------
    RECONSTRUCCION DEL CAMINO OPTIMO

    Se empieza desde la última posición y se
    retrocede hasta llegar al inicio.
    ------------------------------------------------
    */


    // Guardamos posiciones:
    // [0] fila
    // [1] columna
    // [2] valor recogido

    int capacidad = n * n;


    int** camino = new int*[capacidad];


    for (int i = 0; i < capacidad; i++) {

        *(camino + i) = new int[3];

    }



    int fila = n - 1;
    int columna = n - 1;

    int pasos = 0;



    while (fila >= 0 && columna >= 0) {



        *(*(camino + pasos) + 0) = fila;

        *(*(camino + pasos) + 1) = columna;

        *(*(camino + pasos) + 2) =
            *(*(matriz + fila) + columna);



        pasos++;




        // Si llega al inicio termina

        if (fila == 0 && columna == 0) {

            break;

        }



        // Decide si viene desde arriba
        // o desde la izquierda

        if (fila == 0) {


            columna--;


        }

        else if (columna == 0) {


            fila--;


        }

        else {



            if (*(*(dp + (fila - 1)) + columna)
                >
                *(*(dp + fila) + (columna - 1))) {


                fila--;


            }

            else {


                columna--;


            }

        }


    }





    // Mostrar camino correcto
    // Se imprime al revés porque fue almacenado
    // desde el final hasta el inicio.


    cout << "\n===== CAMINO OPTIMO =====\n\n";


    for (int i = pasos - 1; i >= 0; i--) {


        cout << "("
             << *(*(camino + i) + 0)
             << ","
             << *(*(camino + i) + 1)
             << ") -> "


             << *(*(camino + i) + 2)

             << " monedas\n";


    }



    cout << "\nTotal de monedas recolectadas: "
         << *(*(dp + (n - 1)) + (n - 1))
         << endl;





    // Liberación de memoria

    for (int i = 0; i < n; i++) {


        delete[] *(matriz + i);

        delete[] *(dp + i);


    }


    delete[] matriz;

    delete[] dp;




    for (int i = 0; i < capacidad; i++) {


        delete[] *(camino + i);

    }


    delete[] camino;



    return 0;

}