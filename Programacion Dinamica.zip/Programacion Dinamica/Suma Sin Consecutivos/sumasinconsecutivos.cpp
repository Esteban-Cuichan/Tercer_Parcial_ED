/*
---------------------------------------------------------
PROBLEMA: SUMA MAXIMA SIN ELEMENTOS CONSECUTIVOS
---------------------------------------------------------

Enunciado:

Dado un arreglo de N elementos generados
aleatoriamente, determinar la suma maxima posible
sin seleccionar elementos consecutivos.

Ejemplo:

Arreglo:
5 1 2 10 6 2

Solucion:
5 + 10 + 2 = 17

No es permitido seleccionar dos elementos
consecutivos.

Adicionalmente se debe mostrar los elementos
seleccionados para obtener la suma maxima.

Se utilizara Programacion Dinamica para obtener
la mejor solucion posible.

Complejidad:
    Tiempo: O(N)
    Espacio: O(N)

---------------------------------------------------------
*/


#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;


// Devuelve el mayor de dos números

int maximo(int a, int b) {

    return (a > b) ? a : b;

}



int main() {


    // Inicializa la semilla para números aleatorios

    srand((unsigned)time(NULL));



    int n;



    // Validación del tamaño del arreglo

    do {


        cout << "Ingrese el tamaño del arreglo: ";

        cin >> n;



        if (n <= 0) {

            cout << "ERROR: El tamaño debe ser mayor que cero.\n\n";

        }


    } while (n <= 0);





    // Reserva memoria para el arreglo
    // y para la tabla DP

    int* arreglo = new int[n];

    int* dp = new int[n];





    cout << "\n===== ARREGLO GENERADO =====\n\n";



    // Generación de valores aleatorios

    for (int i = 0; i < n; i++) {


        *(arreglo + i) = rand() % 50 + 1;


        cout << *(arreglo + i) << " ";

    }


    cout << endl;





    /*
    -------------------------------------------------
    CONSTRUCCION DE LA TABLA DP

    dp[i] almacena la mejor suma posible
    hasta la posición i.
    -------------------------------------------------
    */



    // Caso especial:
    // arreglo de un solo elemento

    if (n == 1) {


        *(dp + 0) = *(arreglo + 0);


    }

    else {



        // Primera posición

        *(dp + 0) =
            *(arreglo + 0);





        // Segunda posición

        // Se escoge el mayor entre:
        // tomar el primer elemento
        // o tomar el segundo

        *(dp + 1) =

            maximo(

                *(arreglo + 0),

                *(arreglo + 1)

            );






        // Programación Dinámica

        for (int i = 2; i < n; i++) {



            /*
            
            Tenemos dos opciones:

            1) No tomar el elemento actual:
                dp[i-1]

            2) Tomarlo:
                dp[i-2] + arreglo[i]

            Se guarda la mejor opción.

            */


            *(dp + i) =

                maximo(

                    *(dp + (i - 1)),

                    *(dp + (i - 2))
                    +
                    *(arreglo + i)

                );

        }

    }





    // Mostrar tabla DP

    cout << "\n===== TABLA DP =====\n\n";



    for (int i = 0; i < n; i++) {


        cout << *(dp + i) << " ";

    }




    /*
    -------------------------------------------------
    RECONSTRUCCION DE ELEMENTOS SELECCIONADOS

    Se recorre la tabla DP desde el final
    para saber qué elementos forman la solución.
    -------------------------------------------------
    */



    int* seleccion = new int[n];

    int cantidad = 0;



    int posicion = n - 1;



    while (posicion >= 0) {



        // Si estamos en la primera posición

        if (posicion == 0) {


            *(seleccion + cantidad) =
                *(arreglo + posicion);


            cantidad++;

            break;

        }




        /*
        Si el valor actual de DP es diferente
        al anterior significa que este elemento
        fue seleccionado.
        */


        if (*(dp + posicion) !=
            *(dp + (posicion - 1))) {



            *(seleccion + cantidad) =
                *(arreglo + posicion);



            cantidad++;



            // Saltamos una posición
            // porque no puede tomar consecutivos

            posicion -= 2;


        }

        else {



            // No se tomó el elemento

            posicion--;

        }


    }







    // Mostrar solución encontrada

    cout << "\n\n===== ELEMENTOS SELECCIONADOS =====\n\n";



    for (int i = cantidad - 1; i >= 0; i--) {


        cout << *(seleccion + i)
             << " ";

    }



    cout << "\n";




    cout << "\nSuma maxima sin elementos consecutivos: "

         << *(dp + (n - 1))

         << endl;







    // Liberación de memoria

    delete[] arreglo;

    delete[] dp;

    delete[] seleccion;



    return 0;

}